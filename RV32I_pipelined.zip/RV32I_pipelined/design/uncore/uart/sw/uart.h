#ifndef _UART_H_
#define _UART_H_

#include <stdint.h>
/**
* Prototypes of Uart firmware \n
*/

int  uart_putc(char c);
void uart_puts(char *data);


#endif